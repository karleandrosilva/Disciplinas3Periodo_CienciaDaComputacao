package main.model;

public enum Genero {
    Ação, Comédia, Drama, Fantasia, Terror, Suspense, Romance, Animação;
}
